package akhmedoff.usman.thevt.ui.view

interface OnClickListener<in T> {
    fun onClick(item: T)
}