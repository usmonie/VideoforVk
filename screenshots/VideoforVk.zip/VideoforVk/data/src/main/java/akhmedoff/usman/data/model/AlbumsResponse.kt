package akhmedoff.usman.data.model

class AlbumsResponse {
    var count: Int = 0
    var items: List<Album> = mutableListOf()
}