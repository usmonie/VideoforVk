package akhmedoff.usman.data.model

class Files {
    var mp4240: String? = null
    var mp4360: String? = null
    var mp4480: String? = null
    var mp4720: String? = null
    var mp41080: String? = null
    var external: String? = null
    var hls: String? = null
}