package akhmedoff.usman.data.model

enum class CatalogItemType {
    VIDEO,
    ALBUM
}