package akhmedoff.usman.data.model

class CheckTokenResponse {
    var success: Boolean = false
    var user_id: Int = 0
}