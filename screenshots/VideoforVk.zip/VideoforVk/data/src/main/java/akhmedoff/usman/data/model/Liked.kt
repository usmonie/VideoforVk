package akhmedoff.usman.data.model

class Liked(val liked: Int, val copied: Int)