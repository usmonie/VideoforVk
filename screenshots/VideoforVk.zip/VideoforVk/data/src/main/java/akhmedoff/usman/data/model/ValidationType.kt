package akhmedoff.usman.data.model

enum class ValidationType {
    SMS,
    APP
}